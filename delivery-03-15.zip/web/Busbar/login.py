#!/usr/bin/python3

IST_ID = 'ist187107'
host = 'db.tecnico.ulisboa.pt'
port = 5432
password = 'SIBD2020'
db_name = IST_ID

credentials = 'host={} port={} user={} password={} dbname={}'.format(host, port, IST_ID, password, db_name)
